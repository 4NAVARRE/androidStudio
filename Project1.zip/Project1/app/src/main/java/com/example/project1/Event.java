package com.example.project1;

public class Event {
    public String eventName;
    public String Date;

    public Event(String name, String date)
    {
        eventName = name;
        Date = date;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }
}
