package com.example.project1;

import androidx.appcompat.app.AppCompatActivity;

import java.io.Console;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Vector;

public class MainActivity extends AppCompatActivity {

    public EditText input;
    public String name;
    private Button saveActivity, deleteActivity;
    public static Vector<Event> vec = new Vector<>();
    public TextView status;
    public String saveName = "", saveDate = "";
    public static final String APP_PREFERENCES = "mysettings";
    public static final String APP_PREFERENCES_NAME = "text";
    public static final String APP_PREFERENCES_DATE = "date";
    static SharedPreferences mSettings;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();
        input = findViewById(R.id.mainEnter);
        status = findViewById(R.id.statusText);
        saveActivity = (Button) findViewById(R.id.saveBt);
        deleteActivity = (Button) findViewById(R.id.deleteBt);
        mSettings = getSharedPreferences(APP_PREFERENCES, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = mSettings.edit();
        saveName = (mSettings.getString(APP_PREFERENCES_NAME, ""));
        saveDate = (mSettings.getString(APP_PREFERENCES_DATE, ""));
        String[] newName = saveName.split(";");
        String[] newDate = saveDate.split(";");
        if (!saveName.equals(""))
        {
            for (int i = 0; i < newName.length; i++)
            {
                vec.add(new Event(newName[i], newDate[i]));
            }
        }
        saveActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                name = input.getText().toString();
                vec.add(new Event(name, dtf.format(now)));
                saveName = saveName + name + ";";
                saveDate = saveDate + dtf.format(now) + ";";
                status.setText("Event " + vec.lastElement().getEventName() + " has been saved");
                editor.putString(APP_PREFERENCES_NAME, saveName);
                editor.putString(APP_PREFERENCES_DATE, saveDate);
                editor.apply();
            }
        });

        deleteActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    status.setText("Event " + vec.lastElement().getEventName() + " has been deleted");
                    String[] tmpName = saveName.split(";");
                    String[] tmpDate = saveDate.split(";");
                    saveName = "";
                    saveDate = "";
                    String newArr1[] = Arrays.copyOf(tmpName, tmpName.length - 1);
                    String newArr2[] = Arrays.copyOf(tmpDate, tmpDate.length - 1);
                    for (int i = 0; i < newArr1.length; i++)
                    {
                        saveName = saveName + newArr1[i] + ";";
                        saveDate = saveDate + newArr2[i] + ";";
                    }
                    vec.remove(vec.size() - 1);
                    editor.putString(APP_PREFERENCES_NAME, saveName);
                    editor.putString(APP_PREFERENCES_DATE, saveDate);
                    editor.apply();
                }catch (Exception ex)
                {
                    status.setText("Activity list is empty");
                }
            }
        });



    }

}