package com.example.project1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.Button;

public class SavedData extends AppCompatActivity {

    public Button homePage;
    public RecyclerView allData;
    private Adapter dataAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_saved_data);
        homePage = findViewById(R.id.homePage);

        allData = findViewById(R.id.eventList);

        homePage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goToHomePage();
            }
        });
    }

    public void goToHomePage()
    {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

}